package example.moosa.com.musicplayer;

import android.graphics.Color;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;


public class Player extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        viewAllMusic();
        recentlyPlayed();
        artist();
        album();
        folder();
        playlist();
        recentlyadded();


    }

    private void playlist() {
        View playlist = findViewById(R.id.viewplaylist);
        playlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Player.this, "Playlist", Toast.LENGTH_SHORT).show();

            }
        });

    }

    private void recentlyadded() {
        View rca = findViewById(R.id.viewrecentlyadded);
        rca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Player.this, "Recently Added", Toast.LENGTH_SHORT).show();

            }
        });


    }

    private void album() {
        View album = findViewById(R.id.viewalbum);
        album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Player.this, "Album", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void folder() {
        View folder = findViewById(R.id.viewfolder);
        folder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Player.this, "Folder", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void artist() {
        View artst = findViewById(R.id.viewartist);
        artst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Player.this, "Artist", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void recentlyPlayed() {
        View recentPlay = findViewById(R.id.viewrecentlyplayed);
        recentPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Player.this, "Recently Played", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void viewAllMusic() {
        final View allmusic = (View) findViewById(R.id.viewallmusic);
        allmusic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Player.this, "All Music", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
