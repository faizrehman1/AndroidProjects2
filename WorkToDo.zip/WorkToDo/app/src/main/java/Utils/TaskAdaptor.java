package Utils;

import android.content.Context;
import android.graphics.Paint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.List;

import Model.Task;
import firebasesample.moosatodo.com.worktodo.R;

/*
 * Created by Moosa on 8/7/2015.
 */
public class TaskAdaptor extends BaseAdapter {
    List<Task> tasks;
    Context context;

    public TaskAdaptor(List<Task> tasks, Context context) {
        this.tasks = tasks;
        this.context = context;
    }

    @Override
    public int getCount() {
        Log.d("SIZE:->", tasks.size() + "");

        return tasks.size();
    }

    @Override
    public Object getItem(int position) {
        Log.d("getOBJECT", "INVOKED-------------->" + position);

        return tasks.get(position);
    }

    @Override
    public long getItemId(int position) {
        Log.d("getItemID", "INVOKED-------------->" + position);
        return 0;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.listviewadaptor, null, false);
            viewHolder.title = (TextView) convertView.findViewById(R.id.textTitleOfTask);
            viewHolder.description = (TextView) convertView.findViewById(R.id.textDescription);
            viewHolder.importanceRating = (RatingBar) convertView.findViewById(R.id.listItemRatingImporatnce);
            viewHolder.isCompleted = (CheckBox) convertView.findViewById(R.id.checkWorkCompleted);
            convertView.setTag(viewHolder);

        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.title.setText(tasks.get(position).getTaskTitle());

        if (tasks.get(position).isCompleted()) {
            viewHolder.title.setPaintFlags(viewHolder.title.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            viewHolder.title.setPaintFlags(0);
        }
        viewHolder.description.setText(tasks.get(position).getTaskDescription());
        viewHolder.importanceRating.setProgress(tasks.get(position).getImportanceStarRating() * 2);
        viewHolder.isCompleted.setChecked(tasks.get(position).isCompleted());
        viewHolder.isCompleted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tasks.get(position).setIsCompleted(viewHolder.isCompleted.isChecked());
                if (tasks.get(position).isCompleted()) {
                    viewHolder.title.setPaintFlags(viewHolder.title.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                } else {
                    viewHolder.title.setPaintFlags(0);
                }
            }
        });

        return convertView;
    }

    static class ViewHolder {
        TextView title;
        TextView description;
        RatingBar importanceRating;
        CheckBox isCompleted;
    }
}
