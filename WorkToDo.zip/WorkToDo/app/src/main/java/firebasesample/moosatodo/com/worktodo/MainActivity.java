package firebasesample.moosatodo.com.worktodo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.ArrayList;
import java.util.Locale;

import Model.Task;
import Utils.TaskAdaptor;


public class MainActivity extends ActionBarActivity {
    private ListView taskList;
    private Firebase url;
    private TaskAdaptor adapter;
    private ArrayList<Task> myTask;
    private ImageView addTaskButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Firebase.setAndroidContext(MainActivity.this);
        addTaskButton = (ImageView) findViewById(R.id.addImageButton);
        myTask = new ArrayList<>();
        taskList = (ListView) findViewById(R.id.listOfTaskToDo);

        adapter = new TaskAdaptor(myTask, this);

        taskList.setAdapter(adapter);
        taskList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String a = parent.getId() + "-" + view.getId() + " - " + position + id;
                Toast.makeText(MainActivity.this, a, Toast.LENGTH_LONG).show();
            }
        });

        url = new Firebase("https://todolistmoosa.firebaseio.com/firstapptesting/");
        url.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                myTask.clear();
                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                    Task task = dataSnapshot1.getValue(Task.class);
                    myTask.add(task);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {
            }
        });
        addTaskMethod();

    }
/*
        AlertDialog.Builder builder2 = new AlertDialog.Builder(MainActivity.this);
        builder2.setTitle("Edit Task");
        LayoutInflater inflater = (LayoutInflater) MainActivity.this.getSystemService(LAYOUT_INFLATER_SERVICE);
        View view2 = inflater.inflate(R.layout.dialoglayout, null);
        final EditText titleText = (EditText) view2.findViewById(R.id.dialogTitleText);
        final EditText descriptionText = (EditText) view2.findViewById(R.id.dialogDescriptionText);
        final RatingBar ratingBar = (RatingBar) view2.findViewById(R.id.ratingBar);
        titleText.setText(myTask.get(position).getTaskTitle());
        descriptionText.setText(myTask.get(position).getTaskDescription());
        ratingBar.setRating(myTask.get(position).getImportanceStarRating());
        builder2.setView(view2);
        builder2.setPositiveButton("Edit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (!titleText.getText().toString().equals("")) {

                    adapter.notifyDataSetChanged();
                }
            }
        });
        builder2.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder2.show();*/

    private void addTaskMethod() {
        addTaskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Add Task");
                LayoutInflater inflater = (LayoutInflater) MainActivity.this.getSystemService(LAYOUT_INFLATER_SERVICE);
                View view = inflater.inflate(R.layout.dialoglayout, null);
                final EditText titleText = (EditText) view.findViewById(R.id.dialogTitleText);
                final EditText descriptionText = (EditText) view.findViewById(R.id.dialogDescriptionText);
                final RatingBar ratingBar = (RatingBar) view.findViewById(R.id.ratingBar);
                builder.setView(view);
                builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (!titleText.getText().toString().equals("")) {

                            url.push().setValue(new Task(titleText.getText().toString(), "00", (int) ratingBar.getRating(), descriptionText.getText().toString(), false));
                            adapter.notifyDataSetChanged();
                        }
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
            }
        });

    }
}
