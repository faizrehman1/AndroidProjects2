package Model;

/*
 * Created by Moosa on 8/6/2015.
 */
public class Task {
    String taskTitle;
    String taskDate;
    int importanceStarRating;
    String taskDescription;
    boolean completed;

    public Task() {
    }

    public Task(String taskTitle, String taskDate, int importanceStarRating, String taskDescription, boolean completed) {
        this.taskTitle = taskTitle;
        this.taskDate = taskDate;
        this.importanceStarRating = importanceStarRating;
        this.taskDescription = taskDescription;
        this.completed = completed;
    }

    public String getTaskTitle() {
        return taskTitle;
    }

    public void setTaskTitle(String taskTitle) {
        this.taskTitle = taskTitle;
    }

    public String getTaskDate() {
        return taskDate;
    }

    public void setTaskDate(String taskDate) {
        this.taskDate = taskDate;
    }

    public int getImportanceStarRating() {
        return importanceStarRating;
    }

    public void setImportanceStarRating(int importanceStarRating) {
        this.importanceStarRating = importanceStarRating;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public void setTaskDescription(String taskDescription) {
        this.taskDescription = taskDescription;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setIsCompleted(boolean isCompleted) {
        this.completed = isCompleted;
    }


}
