# android-server-communication-sample
Android Server Communication Sample
