package com.github.glomadrian.mvpcleanarchitecture.domain.repository.api.model;

/**
 * @author glomadrian
 */
public class Serie {

    private int available;


    public int getAvailable() {
        return available;
    }

    public void setAvailable(int available) {
        this.available = available;
    }
}
