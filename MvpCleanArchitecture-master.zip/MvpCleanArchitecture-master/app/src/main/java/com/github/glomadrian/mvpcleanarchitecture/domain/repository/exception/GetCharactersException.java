package com.github.glomadrian.mvpcleanarchitecture.domain.repository.exception;

/**
 * @author glomadrian
 */
public class GetCharactersException extends RuntimeException {
}
