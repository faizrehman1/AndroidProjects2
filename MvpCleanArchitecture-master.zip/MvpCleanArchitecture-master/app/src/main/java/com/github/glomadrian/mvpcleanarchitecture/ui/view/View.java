package com.github.glomadrian.mvpcleanarchitecture.ui.view;

/**
 * @author glomadrian
 */
public interface View {
}
